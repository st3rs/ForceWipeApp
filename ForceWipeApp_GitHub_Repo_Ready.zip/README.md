# ForceWipeApp

> Silent panic wipe + shutdown tool for GrapheneOS

## 🚀 Features
- ✅ Wipe internal + external storage
- ✅ Shutdown after wipe
- ✅ GrapheneOS compatible (Device Owner only)

## ⚙️ Setup
```bash
adb install ForceWipeApp.apk
adb shell dpm set-device-owner com.bomb.forcewipeapp/.MyDeviceAdminReceiver
```

## 📄 License
MIT License. Use at your own risk.
